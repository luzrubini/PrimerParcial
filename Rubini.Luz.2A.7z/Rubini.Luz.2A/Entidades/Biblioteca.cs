﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Biblioteca
    {
        private int _capacidad;
        private List<Libro> _libros;
        #region Constructores
        private Biblioteca()
        {
            _libros = new List<Libro>();
        }
        private Biblioteca(int capacidad)
            : this()
        {
            this._capacidad = capacidad;
        }
        #endregion
        #region Propiedades
        public double PrecioDeManuales
        {
            get
            {
                return this.ObtenerPrecio(ELibro.Manual);
            }
        }
        public double PrecioDeNovelas
        {
            get
            {
                return this.ObtenerPrecio(ELibro.Novela);
            }
        }
        public double PrecioTotal
        {
            get
            {
                return (this.ObtenerPrecio(ELibro.Novela) + this.ObtenerPrecio(ELibro.Manual));
            }
        }
        #endregion
        #region Metodos
        public static string Mostrar(Biblioteca e)
        {
            StringBuilder stringBuild = new StringBuilder();
            stringBuild.AppendFormat("Capacidad de la biblioteca: {0}\n", e._capacidad);
            stringBuild.AppendFormat("Total por Manuales: $ {0:#.##}\n", e.PrecioDeManuales);
            stringBuild.AppendFormat("Total por Novelas: $ {0:#.##}\n", e.PrecioDeNovelas);
            stringBuild.AppendFormat("Total: $ {0:#.##}\n", e.PrecioTotal);
            stringBuild.AppendLine("****************************************");
            stringBuild.AppendLine("Listado de Libros");
            stringBuild.AppendFormat("****************************************");

            foreach (Libro libro in e._libros)
            {
                stringBuild.AppendLine("");
                if (libro is Manual)
                { stringBuild.AppendLine(((Manual)libro).Mostrar()); }
                else if (libro is Novela)
                { stringBuild.AppendLine(((Novela)libro).Mostrar()); }
            }

            return stringBuild.ToString();
        }
        private double ObtenerPrecio(ELibro tipoLibro)
        {
            double retorno = 0;

            foreach (Libro libro in this._libros)
            {
                switch (tipoLibro)
                {
                    case ELibro.Manual:
                        if (libro is Manual)
                        {
                            retorno += ((Manual)libro);
                        }
                        break;
                    case ELibro.Novela:
                        if (libro is Novela)
                        {
                            retorno += ((Novela)libro);
                        }
                        break;
                    default:
                        break;
                }
            }

            return retorno;
        }
        public static implicit operator Biblioteca(int capacidad)
        {
            return (new Biblioteca(capacidad)); 
        }
        #endregion
        #region Operadores
        public static Boolean operator ==(Biblioteca e, Libro l)
        {
            Boolean retorno = false;

            foreach (Libro libro in e._libros)
            {
                if (l is Novela && libro is Novela)
                {
                    if (((Novela)libro) == ((Novela)l))
                    {
                        retorno = true;
                        break;
                    }
                }
                else if (l is Manual && libro is Manual)
                {
                    if (((Manual)libro) == ((Manual)l))
                    {
                        retorno = true;
                        break;
                    }
                }
            }

            return retorno;
        }
        public static Boolean operator !=(Biblioteca e, Libro l)
        {
            return !(e == l);
        }
        public static Biblioteca operator +(Biblioteca e, Libro l)
        {
            if (e._libros.Count < e._capacidad)
            {
                if (e != l)
                {
                    e._libros.Add(l);
                }
                else
                {
                    Console.WriteLine("El libro ya está en la biblioteca!!!");
                }
            }
            else
            {
                Console.WriteLine("No hay más lugar en la biblioteca!!!");
            }
            return e;
        }
        #endregion
    }
}
