﻿public enum ETipo
{
    Tecnico,
    Escolar,
    Finanzas,
}

public enum EGenero
{
    Accion,
    Romantica,
    CienciaFiccion,
}

public enum ELibro
{
    Manual,
    Novela,
    Ambos,
}