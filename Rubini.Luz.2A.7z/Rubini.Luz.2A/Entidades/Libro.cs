﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Libro
    {
        protected Autor _autor;
        protected int _cantidadDePaginas;
        protected static Random _generadorDePaginas;
        protected float _precio;
        protected string _titulo;
        #region Propiedades
        public int CantidadDePaginas
        {
            get
            {
                if (this._cantidadDePaginas == 0)
                {
                    this._cantidadDePaginas = Libro._generadorDePaginas.Next(10, 580);
                }
                return this._cantidadDePaginas;
            }
        }
        #endregion
        #region Constructores
        static Libro()
        {
            Libro._generadorDePaginas = new Random();
        }
        public Libro(string titulo, Autor autor, float precio)
        {
            this._titulo = titulo;
            this._autor = autor;
            this._precio = precio;
        }
        public Libro(float precio, string titulo, string nombre, string apellido)
            : this(titulo, new Autor(nombre, apellido), precio)
        { }
        #endregion
        #region Metodos
        private static string Mostrar(Libro l)
        {
            StringBuilder stringBuild = new StringBuilder();
            stringBuild.AppendFormat("TITULO: {0}\nCANTIDAD DE PAGINAS: {1}\nAUTOR: ", l._titulo, l.CantidadDePaginas);
            stringBuild.AppendLine(l._autor);
            stringBuild.AppendFormat("PRECIO: {0:#.##}", l._precio);

            return stringBuild.ToString();
        }
        public static explicit operator string(Libro l)
        {
            return Libro.Mostrar(l);
        }
        #endregion
        #region Sobrecargas
        public static bool operator ==(Libro a, Libro b)
        {
            return (a._autor == b._autor && a._titulo == b._titulo);
        }
        public static bool operator !=(Libro a, Libro b)
        {
            return !(a == b);
        }
        #endregion
    }
}
