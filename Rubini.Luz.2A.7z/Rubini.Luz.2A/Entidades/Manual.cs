﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Manual : Libro
    {
        public ETipo tipo;
        #region Constructores
        public Manual(string titulo, float precio, string nombre, string apellido, ETipo tipoR)
            : base(precio, titulo, nombre, apellido)
        {
            this.tipo = tipoR;
        }
        #endregion
        #region Metodos
        public string Mostrar()
        {
            StringBuilder stringBuild = new StringBuilder();
            stringBuild.AppendLine(((string)this));
            stringBuild.AppendFormat("Tipo: {0}", this.tipo);

            return stringBuild.ToString();
        }
        public static implicit operator double(Manual m)
        {
            return m._precio;
        }
        #endregion
        #region Sobrecargas
        public static bool operator ==(Manual a, Manual b)
        {
            return (((Libro)a) == ((Libro)b) && a.tipo == b.tipo);
        }
        public static bool operator !=(Manual a, Manual b)
        {
            return !(a == b);
        }
        #endregion
    }
}
